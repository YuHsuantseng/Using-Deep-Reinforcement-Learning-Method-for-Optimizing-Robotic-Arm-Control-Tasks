/*==================================================================================================
*   Project              : RTD AUTOSAR 4.7 
*   Platform             : CORTEXM
*   Peripheral           : SIUL2
*   Dependencies         : none
*
*   Autosar Version      : 4.7.0
*   Autosar Revision     : ASR_REL_4_7_REV_0000
*   Autosar Conf.Variant :
*   SW Version           : 3.0.0
*   Build Version        : S32K3_AUTOSAR_4_4_-_R21-11_RTD_3_0_0_D2303_ASR_REL_4_7_REV_0000_20230331
*
*   Copyright 2020 - 2023 NXP Semiconductors
*
*   NXP Confidential. This software is owned or controlled by NXP and may only be
*   used strictly in accordance with the applicable license terms. By expressly
*   accepting such terms or by downloading, installing, activating and/or otherwise
*   using the software, you are agreeing that you have read, and that you agree to
*   comply with and are bound by, such license terms. If you do not agree to be
*   bound by the applicable license terms, then you may not retain, install,
*   activate or otherwise use the software.
==================================================================================================*/

#ifndef SIUL2_PORT_IP_CFG_H
#define SIUL2_PORT_IP_CFG_H

/**
*   @file      Siul2_Port_Ip_Cfg.h
*
*   @addtogroup Port_CFG
*   @{
*/

#ifdef __cplusplus
extern "C"{
#endif


/*==================================================================================================
                                         INCLUDE FILES
 1) system and project includes
 2) needed interfaces from external units
 3) internal and external interfaces from this unit
==================================================================================================*/
#include "S32K344_SIUL2.h"
#include "Siul2_Port_Ip_Types.h"

/*==================================================================================================
*                              SOURCE FILE VERSION INFORMATION
==================================================================================================*/
#define SIUL2_PORT_IP_VENDOR_ID_CFG_H                       43
#define SIUL2_PORT_IP_AR_RELEASE_MAJOR_VERSION_CFG_H        4
#define SIUL2_PORT_IP_AR_RELEASE_MINOR_VERSION_CFG_H        7
#define SIUL2_PORT_IP_AR_RELEASE_REVISION_VERSION_CFG_H     0
#define SIUL2_PORT_IP_SW_MAJOR_VERSION_CFG_H                3
#define SIUL2_PORT_IP_SW_MINOR_VERSION_CFG_H                0
#define SIUL2_PORT_IP_SW_PATCH_VERSION_CFG_H                0

/*==================================================================================================
*                                     FILE VERSION CHECKS
==================================================================================================*/
/* Check if the files Siul2_Port_Ip_Cfg.h and Siul2_Port_Ip_Types.h are of the same version */
#if (SIUL2_PORT_IP_VENDOR_ID_CFG_H != SIUL2_PORT_IP_TYPES_VENDOR_ID_H)
    #error "Siul2_Port_Ip_Cfg.h and Siul2_Port_Ip_Types.h have different vendor ids"
#endif
/* Check if Siul2_Port_Ip_Cfg.h and Siul2_Port_Ip_Types.h are of the same Autosar version */
#if ((SIUL2_PORT_IP_AR_RELEASE_MAJOR_VERSION_CFG_H    != SIUL2_PORT_IP_TYPES_AR_RELEASE_MAJOR_VERSION_H) || \
     (SIUL2_PORT_IP_AR_RELEASE_MINOR_VERSION_CFG_H    != SIUL2_PORT_IP_TYPES_AR_RELEASE_MINOR_VERSION_H) || \
     (SIUL2_PORT_IP_AR_RELEASE_REVISION_VERSION_CFG_H != SIUL2_PORT_IP_TYPES_AR_RELEASE_REVISION_VERSION_H) \
    )
    #error "AutoSar Version Numbers of Siul2_Port_Ip_Cfg.h and Siul2_Port_Ip_Types.h are different"
#endif
/* Check if Siul2_Port_Ip_Cfg.h and Siul2_Port_Ip_Types.h are of the same Software version */
#if ((SIUL2_PORT_IP_SW_MAJOR_VERSION_CFG_H != SIUL2_PORT_IP_TYPES_SW_MAJOR_VERSION_H) || \
     (SIUL2_PORT_IP_SW_MINOR_VERSION_CFG_H != SIUL2_PORT_IP_TYPES_SW_MINOR_VERSION_H) || \
     (SIUL2_PORT_IP_SW_PATCH_VERSION_CFG_H != SIUL2_PORT_IP_TYPES_SW_PATCH_VERSION_H)    \
    )
    #error "Software Version Numbers of Siul2_Port_Ip_Cfg.h and Siul2_Port_Ip_Types.h are different"
#endif
/*==================================================================================================
                                           CONSTANTS
==================================================================================================*/

/*==================================================================================================
                                      DEFINES AND MACROS
==================================================================================================*/
#define SIUL2_MSCR_SSS_MASK                      (0xFU)
#define SIUL2_MSCR_SSS_SHIFT                     (0U)
#define SIUL2_MSCR_SSS_WIDTH                     (4U)
#define SIUL2_MSCR_SSS(x)                        (((uint32)(((uint32)(x)) << SIUL2_MSCR_SSS_SHIFT)) & SIUL2_MSCR_SSS_MASK)

#define SIUL2_MSCR_SRE_MASK                      (0x4000U)
#define SIUL2_MSCR_SRE_SHIFT                     (14U)
#define SIUL2_MSCR_SRE_WIDTH                     (1U)
#define SIUL2_MSCR_SRE(x)                        (((uint32)(((uint32)(x)) << SIUL2_MSCR_SRE_SHIFT)) & SIUL2_MSCR_SRE_MASK)


/*! @brief Definitions for MBDT Functional Group */

/*! @brief User number of configured pins */
#define NUM_OF_CONFIGURED_PINS0 41

#define PORT_START_SEC_CONFIG_DATA_UNSPECIFIED
#include "Port_MemMap.h"

/*! @brief User configuration structure */
extern const Siul2_Port_Ip_PinSettingsConfig g_pin_mux_InitConfigArr0[NUM_OF_CONFIGURED_PINS0];

#define PORT_STOP_SEC_CONFIG_DATA_UNSPECIFIED
#include "Port_MemMap.h"

/*! @brief Defines for user pin and port configurations */
#define ADC_POT0_PIN            11u
#define ADC_POT0_PORT           PTA_L_HALF
#define ADC_POT1_PIN            1u
#define ADC_POT1_PORT           PTA_H_HALF
#define CAN0_RX_PIN             6u
#define CAN0_RX_PORT            PTA_L_HALF
#define CAN0_TX_PIN             7u
#define CAN0_TX_PORT            PTA_L_HALF
#define CAN4_RX_PIN             14u
#define CAN4_RX_PORT            PTE_L_HALF
#define CAN4_TX_PIN             3u
#define CAN4_TX_PORT            PTE_L_HALF
#define LPSPI1PCS3_PIN          1u
#define LPSPI1PCS3_PORT         PTB_H_HALF
#define LPSPI1SCK_PIN           14u
#define LPSPI1SCK_PORT          PTB_L_HALF
#define LPSPI1SIN_PIN           15u
#define LPSPI1SIN_PORT          PTB_L_HALF
#define LPSPI1SOUT_PIN          0u
#define LPSPI1SOUT_PORT         PTB_H_HALF
#define LPSPI2PCS0_PIN          9u
#define LPSPI2PCS0_PORT         PTB_H_HALF
#define LPSPI2SCK_PIN           13u
#define LPSPI2SCK_PORT          PTB_H_HALF
#define LPSPI2SIN_PIN           2u
#define LPSPI2SIN_PORT          PTB_L_HALF
#define LPSPI2SOUT_PIN          3u
#define LPSPI2SOUT_PORT         PTB_L_HALF
#define UART6_RX_PIN            15u
#define UART6_RX_PORT           PTA_L_HALF
#define UART6_TX_PIN            0u
#define UART6_TX_PORT           PTA_H_HALF
#define USER_SW0_PIN            10u
#define USER_SW0_PORT           PTB_H_HALF
#define RGBLED0_RED_PIN         13u
#define RGBLED0_RED_PORT        PTA_H_HALF
#define RGBLED0_GREEN_PIN       14u
#define RGBLED0_GREEN_PORT      PTA_H_HALF
#define RGBLED0_BLUE_PIN        15u
#define RGBLED0_BLUE_PORT       PTA_H_HALF
#define USER_SW1_PIN            3u
#define USER_SW1_PORT           PTB_H_HALF
#define CAN0_STB_PIN            4u
#define CAN0_STB_PORT           PTC_H_HALF
#define CAN0_EN_PIN             5u
#define CAN0_EN_PORT            PTC_H_HALF
#define CAN0_ERRN_PIN           7u
#define CAN0_ERRN_PORT          PTC_H_HALF
#define PWM0_PIN                1u
#define PWM0_PORT               PTA_L_HALF
#define PWM1_PIN                0u
#define PWM1_PORT               PTA_L_HALF
#define PWM5_PIN                11u
#define PWM5_PORT               PTC_L_HALF
#define PWM4_PIN                10u
#define PWM4_PORT               PTC_L_HALF
#define WKPU_1_PIN              3u
#define WKPU_1_PORT             PTD_L_HALF
#define WKPU_0_PIN              2u
#define WKPU_0_PORT             PTA_L_HALF
#define PWM3_PIN                3u
#define PWM3_PORT               PTA_L_HALF
#define PWM7_PIN                2u
#define PWM7_PORT               PTD_L_HALF
#define FLEXIO_RX_PIN           9u
#define FLEXIO_RX_PORT          PTB_L_HALF
#define FLEXIO_TX_PIN           10u
#define FLEXIO_TX_PORT          PTB_L_HALF
#define UART5_RX_PIN            12u
#define UART5_RX_PORT           PTB_H_HALF
#define UART5_TX_PIN            11u
#define UART5_TX_PORT           PTB_H_HALF
#define SYS_PWR_ON_PIN          9u
#define SYS_PWR_ON_PORT         PTC_H_HALF
#define LPSPI5PCS2_PIN          13u
#define LPSPI5PCS2_PORT         PTD_H_HALF
#define LPSPI5SCK_PIN           10u
#define LPSPI5SCK_PORT          PTD_H_HALF
#define LPSPI5SIN_PIN           12u
#define LPSPI5SIN_PORT          PTD_H_HALF
#define LPSPI5SOUT_PIN          11u
#define LPSPI5SOUT_PORT         PTD_H_HALF

/*==================================================================================================
                                           ENUMS
==================================================================================================*/

/*==================================================================================================
                               STRUCTURES AND OTHER TYPEDEFS
==================================================================================================*/

/*==================================================================================================
                               GLOBAL VARIABLE DECLARATIONS
==================================================================================================*/

/*==================================================================================================
                               FUNCTION PROTOTYPES
==================================================================================================*/

#ifdef __cplusplus
}
#endif

#endif /* SIUL2_PORT_IP_CFG_H */

