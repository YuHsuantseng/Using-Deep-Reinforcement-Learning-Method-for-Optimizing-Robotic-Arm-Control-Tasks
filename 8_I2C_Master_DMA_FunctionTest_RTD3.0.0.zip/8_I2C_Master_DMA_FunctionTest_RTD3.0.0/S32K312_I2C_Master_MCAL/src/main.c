/*==================================================================================================
*   Project              : RTD AUTOSAR 4.7
*   Platform             : CORTEXM
*   Peripheral           : S32K3XX
*   Dependencies         : none
*
*   Autosar Version      : 4.7.0
*   Autosar Revision     : ASR_REL_4_7_REV_0000
*   Autosar Conf.Variant :
*   SW Version           : 3.0.0
*   Build Version        : S32K3_RTD_3_0_0_D2303_ASR_REL_4_7_REV_0000_20230331
*
*   Copyright 2020 - 2023 NXP Semiconductors
*
*   NXP Confidential. This software is owned or controlled by NXP and may only be
*   used strictly in accordance with the applicable license terms. By expressly
*   accepting such terms or by downloading, installing, activating and/or otherwise
*   using the software, you are agreeing that you have read, and that you agree to
*   comply with and are bound by, such license terms. If you do not agree to be
*   bound by the applicable license terms, then you may not retain, install,
*   activate or otherwise use the software.
==================================================================================================*/

/**
*   @file main.c
*
*   @addtogroup main_module main module documentation
*   @{
*/

/* Including necessary configuration files. */
#include "Mcal.h"

/* User includes */
#include "Mcu.h"
#include "Mcl.h"
#include "Gpt.h"
#include "Port.h"
#include "Platform.h"

// for I2C (include DMA)
#include "CDD_I2c.h"
#include "CDD_Rm.h"

// for UAAT (Printf)
#include "CDD_Uart.h"
#include <stdio.h>
#include <string.h>


#include "Dio.h"


/* GPT Variable */
static volatile uint8 TimerCount = 0U;

/* LPUART6 Variable */
#define UART_LPUART_INTERNAL_CHANNEL 0U // Uart Channel 0 -> UART6

/* LPI2C0 Variable */
#define I2C0_CHANNEL  0U // I2C Channel 0 -> LPI2C0
#define TRANSFER_SIZE 2U
I2c_DataType txBufferMaster[TRANSFER_SIZE] = {0x1, 0x1}; // register address - 0x1, data - 0x1
I2c_DataType rxBufferMaster[TRANSFER_SIZE] = {0x0, 0x0};
I2c_RequestType pRequest[2] =
{
    /* Slave address */ /*10 bit address*/ /*high speed */ /* expect Nack */ /*repeated start */ /*buffer size */ /*Data direction */ /*Buffer*/
{   0x32,               FALSE,             FALSE,          FALSE,            FALSE,              TRANSFER_SIZE,              I2C_SEND_DATA,      txBufferMaster},
{   0x32,               FALSE,             FALSE,          FALSE,            FALSE,              TRANSFER_SIZE,              I2C_RECEIVE_DATA,      rxBufferMaster}

};

/* Define Interrupt Function */
void Gpt_PitNotification(void)
{
	TimerCount++;
}


/* Define Printf Function */
int _write(int iFileHandle, uint8 *pcBuffer, int iLength) {
	uint32_t remainingByte;
	Uart_StatusType Uart_TransmitStatus = UART_STATUS_TIMEOUT;
	uint32_t timeout = 0xFFFF;

	// check that iFileHandle == 1 to confirm that write is to stdout
    if (iFileHandle != 1)
        return 0;
    Uart_AsyncSend(UART_LPUART_INTERNAL_CHANNEL, pcBuffer, iLength);

    do
	{
    	Uart_TransmitStatus = Uart_GetStatus(UART_LPUART_INTERNAL_CHANNEL, &remainingByte, UART_SEND);

		// Waiting for the transmit  to be completed
	} while ((UART_STATUS_NO_ERROR == Uart_TransmitStatus)&&(0<timeout--));

	return 0;

}

void BSP_Init(void)
{
	/* Init system clock */
	Mcu_Init(NULL_PTR);

	/* Initialize the clock tree and apply PLL as system clock */
	Mcu_InitClock(McuClockSettingConfig_0);
	while (MCU_PLL_LOCKED != Mcu_GetPllStatus())
	{
	    /* Busy wait until the System PLL is locked */
	}

	Mcu_DistributePllClock();
	Mcu_SetMode(McuModeSettingConf_0);

	/* Initialize Port driver */
	Port_Init(NULL_PTR);

	/* Initialize Interrupt */
	Platform_Init(NULL_PTR);
	Platform_InstallIrqHandler(DMATCD0_IRQn, &Dma0_Ch0_IRQHandler, NULL_PTR);
	Platform_InstallIrqHandler(DMATCD1_IRQn, &Dma0_Ch1_IRQHandler, NULL_PTR);

	/* Initialize Mcl */
	Mcl_Init(NULL_PTR);

	/* Initialize Rm driver for using DmaMux */
	Rm_Init(NULL_PTR);

	/* Initialize Gpt driver */
	Gpt_Init(NULL_PTR);

	/* Init i2c instances */
	I2c_Init(NULL_PTR);

	/* Initializes an UART driver */
	Uart_Init(NULL_PTR);

}


uint8_t I2C_Master_Transmit(uint8 channel, I2c_RequestType I2c_Request)
{
	I2c_SyncTransmit(channel, &I2c_Request); // Master Send Data
	// Read I2C Status
	if (I2c_GetStatus(channel) == I2C_CH_FINISHED) {
		return 0;
	}
	return 1;
}

void delay_ms(uint8 sec)
{
	/* TimerCount Reset */
	TimerCount = 0;
	/* Start the Gpt timer */
	Gpt_StartTimer(GptConf_GptChannelConfiguration_GptChannelConfiguration_0, 30000U);
	/* Enable the Gpt notification to get the event */
	Gpt_EnableNotification(GptConf_GptChannelConfiguration_GptChannelConfiguration_0);
	while (TimerCount < sec);
	/* Stop the Gpt timer */
	Gpt_StopTimer(GptConf_GptChannelConfiguration_GptChannelConfiguration_0);
}

/*!
  \brief The main function for the project.
  \details The startup initialization sequence is the following:
 * - startup asm routine
 * - main()
*/
int main(void)
{
    /* Write your code here */
	uint16_t I2C_Test_Times = 1;

	/* Driver Initialize */
	BSP_Init();
	printf("BSP Init Finish! \r\n");
	delay_ms(10);
	// Add LED Toggle
	// Add #include "Dio.h"
    Dio_WriteChannel(DioConf_DioChannel_RGBLED_RED, STD_HIGH);
    delay_ms(10);
    Dio_WriteChannel(DioConf_DioChannel_RGBLED_RED, STD_LOW);

	for(int times=0; times<I2C_Test_Times; times++)
	{
		/* I2C0 Master send data - Write */
		if ( I2C_Master_Transmit(I2C0_CHANNEL, pRequest[0]))
		{
			printf("Times:%d - I2C Master Send Write Data Error! \r\n", times+1);
			break;
		}
		printf("Times:%d - I2C Master Send Write Data Finish! \r\n", times+1);
		delay_ms(10);
		txBufferMaster[1]++;
		if (txBufferMaster[1]==11)
		{
			txBufferMaster[1]=1;
		}

		/* I2C0 Master send data - Read */
		if (I2C_Master_Transmit(I2C0_CHANNEL, pRequest[1])) {
		    printf("Times:%d - I2C Master Send Read Data Error! \r\n", times + 1);
		    break;
		}
		printf("Times:%d - I2C Master Send Read Data is: 0x%x 0x%x! \r\n",  times+1, rxBufferMaster[0], rxBufferMaster[1]);
		delay_ms(10);
	}

	return 0;
}

/** @} */
